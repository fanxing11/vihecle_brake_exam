#include "Filter.h"
#include "const.h"


void LogTime()
{
	LARGE_INTEGER lv;

	// ��ȡÿ�����CPU Performance Tick
	QueryPerformanceFrequency( &lv );

	// ת��Ϊÿ��Tick������
	double secondsPerTick = 1.0 / lv.QuadPart;

	// ��ȡCPU���е����ڵ�Tick��
	QueryPerformanceCounter( &lv );

	// ����CPU���е����ڵ�ʱ��
	// ��GetTickCount��timeGetTime���Ӿ�ȷ
	double timeElapsedTotal = secondsPerTick * lv.QuadPart;

	//cout.precision( 6 );
	//cout << fixed << showpoint << timeElapsedTotal << endl;

	g_logger.TraceWarning("time now is %.6f",timeElapsedTotal);

}

Filter::Filter(UINT nSize)
	:m_dSum(0.0)
	,m_nCount(0)
{
	g_logger.TraceInfo("Filter::Filter -in");

}

Filter::~Filter(void)
{
	g_logger.TraceInfo("Filter::~Filter");

	vector <double>().swap(m_vtData);
}

void Filter::AddData(double dData)
{
	m_dSum += dData;
	m_nCount++;
}

double Filter::GetMeanData()
{
	if (0 != m_nCount)
	{
		return m_dSum / m_nCount;
	}
	else
	{
		return 0;
	}
}

void Filter::AddData1(const double dData)
{
	m_vtData.push_back(dData);
}

void Filter::ResetMid()
{
	m_vtData.clear();
}

double Filter::GetMidValue()
{
	try
	{
		UINT nData = m_vtData.size();
		g_logger.TraceInfo("Filter::GetMidValue,sum point count is %d.",nData);

		if (!is_sorted(m_vtData.begin(),m_vtData.end()))
		{
			sort(m_vtData.begin(),m_vtData.end(),less<double>());
		}
		return m_vtData[nData/2];
	}
	catch (exception &e)
	{
		DWORD dw = GetLastError();
		g_logger.TraceError("Filter::GetMidValue:%d-%s",dw,e.what());
	}

}

double Filter::GetMaxValue()
{
	try{
		if (!is_sorted(m_vtData.begin(),m_vtData.end()))
		{
			sort(m_vtData.begin(),m_vtData.end(),less<double>());
		}
		return m_vtData[m_vtData.size()-1];
	}
	catch (exception &e)
	{
		DWORD dw = GetLastError();
		g_logger.TraceError("Filter::GetMidValue:%d-%s",dw,e.what());
	}
	
}

void Filter::GetPartIndex(UINT &nBegin,UINT &nEnd)
{
	if (!is_sorted(m_vtData.begin(),m_vtData.end()))
	{
		sort(m_vtData.begin(),m_vtData.end(),less<double>());
	}
	nBegin = 1;
}

double Filter::GetPartMeanValue(const UINT nBegin,const UINT bEnd)
{
	return 0;;
}

