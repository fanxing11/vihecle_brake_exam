# README.MD
This is a server part about DAQ with technique listed:
1. UDP socket: bind revfrom sendto..
2. message: GetMessage _beginthreadex PostThreadMessage
3. multi-thread: main;communicate;DAQ;analysis
4. multi-thread synic with Event
5. windows program without a console or GUI
6. File operation: binary, text and INI file, check directory/file existing, list files, make directory
7. USE include string
8. use of namespace
9. DAQ the Advantech USB-4716, streaming AI mode 
10. logger class